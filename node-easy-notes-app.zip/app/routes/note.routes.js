module.exports = app => {
    const Notes = require("../controller/controller.js");
    var router = require("express").Router();
    router.post("/" , Notes.create);
    router.get("/",Notes.findAll);
    router.get("/",Notes.findOne);
    router.put("/:id",Notes.update);
    router.delete("/:id",Notes.delete);
    router.delete("/",Notes.deleteAll);
    app.use('/api/notes',router);

};